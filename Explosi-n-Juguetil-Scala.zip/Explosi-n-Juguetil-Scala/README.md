Explosión-Juguetil-Scala
